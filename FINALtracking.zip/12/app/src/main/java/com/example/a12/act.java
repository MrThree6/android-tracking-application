package com.example.a12;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.example.a12.intentb.id;

public class act extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act);

    }

    public static String username;


    //log in mehtod
public void sendlogininfo(View view){

    final TextView name = findViewById(R.id.editText);

    final TextView pass = findViewById(R.id.editText4);

String url ="http://allliii-001-site1.atempurl.com/login.php?username="+name.getText()+"&password="+pass.getText();


    RequestQueue q = Volley.newRequestQueue(this);



    JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url,null ,new Response.Listener<JSONArray>() {
        @Override
        public void onResponse(JSONArray response) {
            try {
                Toast.makeText(getApplicationContext(), "response from server >>> :" + response, Toast.LENGTH_LONG).show();
                // json object processing


                        JSONObject room = response.getJSONObject(0);

                        username =room.getString("username");
                        changeact();






            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    },
            new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), "!!!WRONG!!! >>>" + error.getMessage(), Toast.LENGTH_LONG).show();
                }
            });



    q.add(request);


}

public void changeact(){
    if(username!=null){
        Intent intent= new Intent(this,MainActivity.class);
        startActivity(intent);
}




}


}
