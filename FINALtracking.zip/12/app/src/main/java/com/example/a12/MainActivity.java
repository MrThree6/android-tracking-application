package com.example.a12;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.media.MediaSync;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import com.android.volley.*;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.minew.beaconplus.sdk.MTCentralManager;
import com.minew.beaconplus.sdk.MTFrameHandler;
import com.minew.beaconplus.sdk.MTPeripheral;
import com.minew.beaconplus.sdk.enums.BluetoothState;
import com.minew.beaconplus.sdk.frames.MinewFrame;
import com.minew.beaconplus.sdk.interfaces.MTCentralManagerListener;
import com.minew.beaconplus.sdk.interfaces.OnBluetoothStateChangedListener;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.os.Handler;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import no.nordicsemi.android.support.v18.scanner.BluetoothLeScannerCompat;
import no.nordicsemi.android.support.v18.scanner.ScanCallback;
import no.nordicsemi.android.support.v18.scanner.ScanFilter;
import no.nordicsemi.android.support.v18.scanner.ScanResult;
import no.nordicsemi.android.support.v18.scanner.ScanSettings;

import static com.example.a12.act.username;
import static com.example.a12.intentb.id;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_ENABLE_BT =1 ;
    private BluetoothAdapter bluetoothAdapter;
    private static final int PERMISSION_REQUEST_COARSE_LOCATION = 1;
    private BluetoothAdapter mBluetoothAdapter  = null;
    private BluetoothLeScanner mBluetoothLeScanner = null;
    public static final int REQUEST_BT_PERMISSIONS = 0;
    public static final int REQUEST_BT_ENABLE = 1;
    private Handler mHandler = null;
    private Button btnScan = null;
    private boolean mScanning= false;




    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{ Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }else {
            Toast.makeText(getApplicationContext(), "permission >>> :" , Toast.LENGTH_LONG).show();
        }
        setContentView(R.layout.activity_main);



        LocalBroadcastManager.getInstance(this).registerReceiver(mMessageReceiver,
                new IntentFilter("location data"));
// network call for id

        String URL_post = "http://allliii-001-site1.atempurl.com/LastID.php?lastID="+username;

        RequestQueue q = Volley.newRequestQueue(this);
        JsonArrayRequest requestid = new JsonArrayRequest(Request.Method.GET, URL_post,null ,new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try {

                    JSONObject room = response.getJSONObject(response.length()-1);

                    room = response.getJSONObject(response.length()-1);


                    id = room.getInt("ID");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }},
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                       Toast.makeText(getApplicationContext(), "!!!WRONG!!! >>>" + error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
        q.add(requestid);


    }


    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // Get extra data included in the Intent
            String message = intent.getStringExtra("message");
            TextView input = findViewById(R.id.textView2);

            input.setText(message);

            Log.d("receiver", "Got message: " + message);
        }
    };


    @SuppressLint("SetTextI18n")
    public void startforeground(View view) {
        TextView input = findViewById(R.id.textView2);
        input.setText("TRAKING: enabled \n sending location...");
        MTCentralManager mtCentralManager = MTCentralManager.getInstance(this);

        Intent serviceIntent = new Intent(this, intentb.class);

        intentb.disabled = false;
       // start background service;
        ContextCompat.startForegroundService(this, serviceIntent);

    }





    public void stopforeground(View view) {
        TextView input = findViewById(R.id.textView2);

        input.setText("TRAKING: disabled ");
        Intent serviceIntent = new Intent(this, intentb.class);
        stopService(serviceIntent);

        intentb.disabled = true;


    }


    @Override
    protected void onDestroy() {
        // Unregister since the activity is about to be closed.
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mMessageReceiver);

        super.onDestroy();
    }

    private ScanCallback scanCallback = new  ScanCallback() {


        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            Log.i("result", result.getDevice().toString());
            Log.i("ressi", ":"+result.getRssi());


        }


    };



}




