package com.example.a12;

import android.app.IntentService;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.ParcelUuid;
import android.util.Log;

import android.app.IntentService;
import android.app.Notification;
import android.content.Intent;
import android.os.Build;
import android.os.PowerManager;
import android.os.SystemClock;

import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.minew.beaconplus.sdk.MTCentralManager;
import com.minew.beaconplus.sdk.MTFrameHandler;
import com.minew.beaconplus.sdk.MTPeripheral;
import com.minew.beaconplus.sdk.enums.FrameType;
import com.minew.beaconplus.sdk.frames.AccFrame;
import com.minew.beaconplus.sdk.frames.ForceFrame;
import com.minew.beaconplus.sdk.frames.HTFrame;
import com.minew.beaconplus.sdk.frames.IBeaconFrame;
import com.minew.beaconplus.sdk.frames.LightFrame;
import com.minew.beaconplus.sdk.frames.MinewFrame;
import com.minew.beaconplus.sdk.frames.PIRFrame;
import com.minew.beaconplus.sdk.frames.TemperatureFrame;
import com.minew.beaconplus.sdk.frames.TlmFrame;
import com.minew.beaconplus.sdk.frames.TvocFrame;
import com.minew.beaconplus.sdk.frames.UidFrame;
import com.minew.beaconplus.sdk.frames.UrlFrame;
import com.minew.beaconplus.sdk.interfaces.MTCentralManagerListener;
import com.nexenio.bleindoorpositioning.IndoorPositioning;
import com.nexenio.bleindoorpositioning.ble.advertising.AdvertisingPacket;
import com.nexenio.bleindoorpositioning.ble.beacon.Beacon;
import com.nexenio.bleindoorpositioning.ble.beacon.BeaconManager;
import com.nexenio.bleindoorpositioning.ble.beacon.BeaconUpdateListener;
import com.nexenio.bleindoorpositioning.ble.beacon.Eddystone;
import com.nexenio.bleindoorpositioning.ble.beacon.IBeacon;
import com.nexenio.bleindoorpositioning.location.Location;
import com.nexenio.bleindoorpositioning.location.LocationListener;
import com.nexenio.bleindoorpositioning.location.provider.BeaconLocationProvider;
import com.nexenio.bleindoorpositioning.location.provider.EddystoneLocationProvider;
import com.nexenio.bleindoorpositioning.location.provider.IBeaconLocationProvider;
import com.nexenio.bleindoorpositioning.location.provider.LocationProvider;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import no.nordicsemi.android.support.v18.scanner.BluetoothLeScannerCompat;
import no.nordicsemi.android.support.v18.scanner.ScanCallback;
import no.nordicsemi.android.support.v18.scanner.ScanFilter;
import no.nordicsemi.android.support.v18.scanner.ScanResult;
import no.nordicsemi.android.support.v18.scanner.ScanSettings;

import static android.os.Build.ID;
import static com.example.a12.act.username;
import static com.example.a12.app.CHANNEL_ID;

public class intentb extends IntentService {
    public static boolean disabled=true;
    public static int id;
    public static int CommnetID=0;
    public MTCentralManager mtCentralManager;
    //public ArrayList<MinewFrame> advFrames;
    private static  final String tag="intent B:";
    private String NewsData;
    public static List<MTPeripheral> resultpripherals;
    public double room1;
    public double room2;
    public double room3;
    public intentb() {
        super("intentb");
    }
    private PowerManager.WakeLock wakeLock;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(tag, "onCreate");
       // LocalBroadcastManager.getInstance(this).registerReceiver(resetReceiver,new IntentFilter("reset notif"));

     notif();
    }

    public void notif(){
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                "back ground App:Wakelock");
        wakeLock.acquire();
        Log.d(tag, "Wakelock acquired");

        // notification ***
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent notficationintent = new Intent(this, MainActivity.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
                    notficationintent, 0);
            Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setContentTitle("sending location")
                    .setContentText("Running...")
                    .setSmallIcon(R.drawable.ic_explore_black_24dp)
                    .setContentIntent(pendingIntent)
                    .build();

            startForeground(1, notification);
        }

    }


    public void notif(String room){
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                "back ground App:Wakelock");
        wakeLock.acquire();
        Log.d(tag, "Wakelock acquired");

        // notification ***
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent notficationintent = new Intent(this, MainActivity.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
                    notficationintent, 0);
            Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setContentTitle("EMERGENCY:")
                    .setContentText(room)
                    .setSmallIcon(R.drawable.ic_proc_alert).setContentIntent(pendingIntent)
                    .build();

            startForeground(1, notification);
        }

    }



    @Override
    protected void onHandleIntent( Intent intent) {

        Log.d(tag," in onHANDLE INTENT ");







        //bluetooth scan
              BLEscan();

        IndoorPositioning.registerLocationListener(new LocationListener() {
            @Override
            public void onLocationUpdated(LocationProvider locationProvider, Location location) {
                Log.d("locx","dev location:::>   "+locationProvider.getLocation());
               Location roomf=new Location(52.51241494408055,13.390923696709284);
               Location rooms=new Location(52.51241817994866,13.390767908948862);
               Location roomt=new Location(52.512390301005585,13.39077285305349);

                room1=location.getDistanceTo(roomf);
                room2=location.getDistanceTo(rooms);
                room3=location.getDistanceTo(roomt);
                Log.d("locx","dev location:::>   "+room1+" : "+room2+" : "+room3);


            }
        });



        // if disabled = true the loop ends
            while(!disabled) {




       // sending location data

            String URL_post = "http://allliii-001-site1.atempurl.com/Update_location.php";


             StringRequest stringreq = new StringRequest(Request.Method.POST, URL_post, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Toast.makeText(getApplicationContext(), "response from server >>> :" + response, Toast.LENGTH_LONG).show();

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), "!!!WRONG!!! >>>" + error.getMessage(), Toast.LENGTH_LONG).show();
                }
            }){

                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    // sending location




                    HashMap<String, String> params = new HashMap<String, String>();


                    params.put("username", ""+username);
                    params.put("room1",""+room1);
                    params.put("room2",""+room2);
                    params.put("room3",""+room3);


                    return params;
                }


            };




          // get deployment info from database

            String url="http://allliii-001-site1.atempurl.com/index.php?Number="+id+"&username="+username;


                JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url,null ,new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                        Toast.makeText(getApplicationContext(), "response from server >>> :" + response, Toast.LENGTH_LONG).show();
                        // json object processing
                        if (!"[]".equals("" + response)) {
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject room = response.getJSONObject(i);

                                String Emessage =room.getString("Emergency_Message");

                                sendMessage(""+Emessage  + "\n\n");
                                id = room.getInt("ID");
                                Log.d("control",""+Emessage);


                                notif(Emessage);
                            }
                        }


                        } catch (JSONException e) {
                        e.printStackTrace();
                     }
                    }
                    },
                        new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "!!!WRONG!!! >>>" + error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });


                RequestQueue q = Volley.newRequestQueue(this);
                q.add(request);
                q.add(stringreq);


            // delay on loop
                try {
                    Thread.sleep(10000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }


            }

    }


    private void sendMessage(String name) {
        Log.d("sender", "Broadcasting message");
        Intent intent = new Intent("location data");

        intent.putExtra("message", ""+name);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    public String encryption(String message){
        // encryption
        String  encryptedMessage = "";
        int key=1024;
        char ch;
        for(int i = 0; i < message.length(); ++i){
            ch = message.charAt(i);

            if(ch >= 'a' && ch <= 'z'){
                ch = (char)(ch + key);

                if(ch > 'z'){
                    ch = (char)(ch - 'z' + 'a' - 1);
                }

                encryptedMessage += ch;
            }
            else if(ch >= 'A' && ch <= 'Z'){
                ch = (char)(ch + key);

                if(ch > 'Z'){
                    ch = (char)(ch - 'Z' + 'A' - 1);
                }

                encryptedMessage += ch;
            }
            else {
                encryptedMessage += ch;
            }
        }

    return encryptedMessage;
    }

    public String decryption(String message){
        String  decryptedMessage = "";
        int key=1024;
        char ch;

        for(int i = 0; i < message.length(); ++i){
            ch = message.charAt(i);

            if(ch >= 'a' && ch <= 'z'){
                ch = (char)(ch - key);

                if(ch < 'a'){
                    ch = (char)(ch + 'z' - 'a' + 1);
                }

                decryptedMessage += ch;
            }
            else if(ch >= 'A' && ch <= 'Z'){
                ch = (char)(ch - key);

                if(ch < 'A'){
                    ch = (char)(ch + 'Z' - 'A' + 1);
                }

                decryptedMessage += ch;
            }
            else {
                decryptedMessage += ch;
            }
        }

    return decryptedMessage;
    }
//scan beacon


    public ScanCallback mScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, @NonNull ScanResult result) {
            super.onScanResult(callbackType, result);

            if(result.getDevice().getAddress().equals("AC:23:3F:A2:8A:39")||result.getDevice().getAddress().equals("AC:23:3F:A2:8B:8A")||result.getDevice().getAddress().equals("AC:23:3F:A2:47:2D")){
                Log.i("result", result.getDevice()+":["+result.getRssi()+"]");
                processScanResult(result);

            }


        }
    };





    public BluetoothLeScannerCompat scanner;
    public void BLEscan(){
        scanner = BluetoothLeScannerCompat.getScanner();

        ScanSettings settings = new ScanSettings.Builder()
                .setLegacy(false)
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .setReportDelay(10000)
                .setUseHardwareBatchingIfSupported(false)
                .build();
        //List<ScanFilter> filters = new ArrayList<>();
        //filters.add(new ScanFilter.Builder().setServiceUuid(ParcelUuid.fromString("E2C56DB5-DFFB-48D2-B060-D0F5A71096E0")).build());


        scanner.startScan(mScanCallback);
        // scanner.startScan(mScanCallback);

    }

    private void processScanResult(ScanResult scanResult) {
        String macAddress = scanResult.getDevice().getAddress();
        byte[] advertisingData = scanResult.getScanRecord().getBytes();
        int rssi = scanResult.getRssi();
       AdvertisingPacket advertisingPacket =BeaconManager.processAdvertisingData(macAddress, advertisingData, rssi);
        if (advertisingPacket != null) {
            Beacon beacon = BeaconManager.getBeacon(macAddress, advertisingPacket);
            if (beacon instanceof Eddystone && !beacon.hasLocation()) {
                beacon.setLocationProvider(createDebuggingLocationProvider((Eddystone) beacon));
            }else {
                Log.i("result", "not ibeacon");}
        }else {
            Log.i("result", "beacon null"); }

    }




    private static EddystoneLocationProvider<Eddystone> createDebuggingLocationProvider(Eddystone iBeacon) {
        final Location beaconLocation = new Location();
        switch (iBeacon.getMacAddress()) {
            case "AC:23:3F:A2:47:2D": {
                beaconLocation.setLatitude(52.512437);
                beaconLocation.setLongitude(13.391124);
                beaconLocation.setAltitude(36);
                break;
            }
            case "AC:23:3F:A2:8A:39": {
                beaconLocation.setLatitude(52.512411788476356);
                beaconLocation.setLongitude(13.390875654442985);
                beaconLocation.setAltitude(36);
                break;
            }
            case "AC:23:3F:A2:8B:8A":{
                beaconLocation.setLatitude(52.51240486636751);
                beaconLocation.setLongitude(13.390770270005437);
                beaconLocation.setAltitude(36);
                break;
            }

        }


        return new EddystoneLocationProvider<Eddystone>(iBeacon) {
            @Override
            protected void updateLocation() {
                this.location = beaconLocation;
            }

            @Override
            protected boolean canUpdateLocation() {
                return true;
            }
        };
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(tag, "onDestroy");
       // LocalBroadcastManager.getInstance(this).unregisterReceiver(resetReceiver);
        wakeLock.release();
        Log.d(tag, "Wakelock released");
        scanner.stopScan(mScanCallback);


    }
}

